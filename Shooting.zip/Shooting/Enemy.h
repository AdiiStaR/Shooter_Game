#pragma once

#include <SFML/Graphics.hpp>
#include "player.h"

class Enemy {
public:
    sf::Sprite shape;
    int HP;
    int HPMax;

    Enemy(sf::Texture* texture, sf::Vector2u windowSize);
    ~Enemy();
};
