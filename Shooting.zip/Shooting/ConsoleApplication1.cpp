//#include<SFML\Graphics.hpp>
//#include<SFML\Window.hpp>
//#include<SFML\System.hpp>
//#include<vector>
//#include <cstdlib>
//#include<iostream>
//#include<math.h>
//
//using namespace sf;
//
///*
//Vector Math
//|V| = sqrt(pow(2,Vx) + pow(2,Vy));
//
//Normalize Vector
//U = V/|V| = (Vx,Vy) / sqrt(pow(2,Vx) + pow(2,Vy));
//
//*/
//int main() {
//	srand(time(NULL));
//
//	RenderWindow window(VideoMode(1000, 1000), "Shooter");
//	window.setFramerateLimit(144);
//
//	//Balls
//	CircleShape projectile;
//	projectile.setFillColor(Color::Red);
//	projectile.setRadius(5.f);
//
//	RectangleShape enemy;
//	enemy.setFillColor(Color::Yellow);
//	enemy.setSize(Vector2f(50.f, 50.f));
//
//
//	CircleShape player;
//	player.setFillColor(Color::White);
//	player.setRadius(50.f);
//	player.setPosition(window.getSize().x / 2 - player.getRadius(), window.getSize().y - player.getRadius() * 2 - 10.f); //it will place the player to the bottom of the screen in centre
//	Vector2f playerCenter;
//
//
//	std::vector<CircleShape> projectiles;
//	projectiles.push_back(CircleShape(projectile));
//
//	std::vector<RectangleShape> enemies;
//	enemies.push_back(RectangleShape(enemy));
//
//	//Score Box
//	RectangleShape scoreBox;
//	scoreBox.setFillColor(Color::Green);
//	scoreBox.setSize(Vector2f(120.f, 60.f));
//	scoreBox.setPosition({870.f,10.f});
//	
//	
//	//Health Bar
//	RectangleShape healthBar;
//	healthBar.setFillColor(Color::Red);
//	healthBar.setSize(Vector2f(120.f, 60.f));
//	healthBar.setPosition({0.f,10.f});
//
//	int shootTimer = 0;
//	int enemySpawnTime = 0;
//	int score = 0;
//	int health = 15;
//
//
//
//	while (window.isOpen())
//	{
//		Event evnt;
//		while (window.pollEvent(evnt)) {
//			if (evnt.type == Event::Closed)
//				window.close();
//			if (evnt.type == Event::KeyPressed && evnt.key.code == Keyboard::Escape)
//				window.close();
//
//		}
//		//Update
//		if (health == 0)
//			window.display();
//
//		//Player
//		playerCenter = Vector2f(player.getPosition().x + player.getRadius(), player.getPosition().y + player.getRadius());
//		if (shootTimer < 10)
//			shootTimer++;
//
//		if(Mouse::getPosition(window).x >= 0 && Mouse::getPosition(window).x <= window.getSize().x - player.getGlobalBounds().height) //Prevent the player from going out of the screen
//			player.setPosition(Mouse::getPosition(window).x, player.getPosition().y);
//
//
//		//Projectiles
//		if (Mouse::isButtonPressed(Mouse::Left) && shootTimer >= 10) //Shoot
//		{
//			projectile.setPosition(playerCenter);
//			projectiles.push_back(CircleShape(projectile));
//
//			shootTimer = 0;
//
//		}
//
//		for (size_t i = 0;i < projectiles.size();++i)
//		{
//			projectiles[i].move(0.f, -10.f);
//
//			if (projectiles[i].getPosition().y <= 0)
//				projectiles.erase(projectiles.begin() + i);
//
//		}
//
//		//Enemies
//		if (enemySpawnTime < 40)
//			enemySpawnTime++;
//
//		if (enemySpawnTime >= 40) {
//			enemy.setPosition((rand() % int(window.getSize().x - enemy.getSize().x)), 0.f);
//			enemies.push_back(RectangleShape(enemy));
//			enemySpawnTime = 0;
//		}
//
//		for (size_t i = 0;i < enemies.size();++i)
//		{
//			enemies[i].move(0.f, 2.f);
//			if (enemies[i].getPosition().y > window.getSize().y - 20 )	//If enemies are out of screen they ll eraase automatically
//				enemies.erase(enemies.begin() + i);					
//
//		}
//
//
//		//Collision
//		for (int i = 0;i < projectiles.size();++i) 
//		{
//			for (int j = 0;j < enemies.size();++j) 
//			{
//				if (projectiles[i].getGlobalBounds().intersects(enemies[j].getGlobalBounds()))
//				{
//					score++;
//					std::cout << score << std::endl;
//					
//					enemies.erase(enemies.begin() + j);
//					projectiles.erase(projectiles.begin() + i);
//					break;
//				}
//				
//			}
//					
//		}
//		//Too erase the enemies when it collids with the player
//		for (int k = 0;k < enemies.size();++k)
//		{
//			if (player.getGlobalBounds().intersects(enemies[k].getGlobalBounds()))
//			{
//				health--;
//				enemies.erase(enemies.begin() + k);
//				break;
//			}
//		}
//		//UI
//		healthBar.setSize(Vector2f(120.f, 60.f));
//
//
//
//		//Draw
//		window.clear();
//		
//		window.draw(player);
//		window.draw(healthBar);
//		window.draw(scoreBox);
//
//		for (size_t i = 0; i < enemies.size();++i) {
//			window.draw(enemies[i]);
//		}
//		for (size_t i = 0;i < projectiles.size();++i) {
//			window.draw(projectiles[i]);
//		}
//
//		
//		window.display();
//	}
//
//}